

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Depstore extends JFrame
{
    JLabel Customer,Name,Contact,Hawk;
    JTextField tNumber,tName,tContact,tHawk;
    JComboBox c1,c2;
    
    JTextArea area1;
    JButton reset,print,receipt;
    
    Depstore()
    {
        

        //labels
        
        Customer = new JLabel ("Customer no:");
        Customer.setBounds(20, 50, 120, 30);
        
        Name = new JLabel ("Name:");
        Name.setBounds(20, 100, 120, 30);
        
        Contact = new JLabel ("Contact:");
        Contact.setBounds(20, 150, 120, 30);
        
        Hawk = new JLabel ("Hawk:");
        Hawk.setBounds(20, 200, 120, 30);
        
            
        //set ng text fields
        tNumber = new JTextField();
        tNumber.setBounds(150, 50, 200, 30);
        
        tName = new JTextField();
        tName.setBounds(150, 100, 200, 30);
        
        tContact = new JTextField();
        tContact.setBounds(150, 150, 200, 30);
        

        
        //combo box
        String bag []={"Sling bag","Backpack","Belt bag"};
        c1 = new JComboBox(bag);
        c1.setBounds(200, 200, 120, 30);


       

        
        //buttons
        reset = new JButton("reset");
        reset.setBounds(400, 100, 80, 40);
        
        print = new JButton("print");
        print.setBounds(490, 100, 80, 40);
        
        receipt = new JButton("receipt");
        receipt.setBounds(580, 100, 80, 40);
        
        //TextArea
        area1 = new JTextArea();
        area1.setBounds(400, 160, 80, 40);
        area1.setSize(260,260);
        
        // add content pane
        getContentPane().add(reset);
        getContentPane().add(receipt);
        getContentPane().add(print);
        getContentPane().add(area1);
        getContentPane().add(Customer);
        getContentPane().add(Name);
        getContentPane().add(Contact);
        getContentPane().add(Hawk);
        getContentPane().add(tName);
        getContentPane().add(tContact);
        getContentPane().add(tNumber);
       
        
        getContentPane().add(c1);
        
        
        setSize(700,550);
        setLayout(null);
        
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //buttons actions
        
        reset.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                tName.setText("");
                
                tContact.setText("");
                
                tNumber.setText("");
                
                area1.setText("");
            }        
        });
        
        print.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try{
                area1.print();
                }
                catch(PrinterException ex)
                {
                System.out.println("ex.getMessage");
                }}
        });
        receipt.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                
            {
             area1.append("\n"+"CustomerName: "+tName.getText()+"\nCustomer Contact: "+tContact.getText()+"\nCstomer Number: "+tNumber.getText());
                area1.append("\nHawks: "+c1.getSelectedItem() + "\n");
                area1.append("\nDrinks: "+c2.getSelectedItem());
                
                    
                }
              
       
                }
        
        });
    }
    
    public static void main(String[] args){
        new Depstore();
      }
    }