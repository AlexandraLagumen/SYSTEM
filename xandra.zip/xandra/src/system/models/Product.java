package system.models;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;

import xandra.Depstore;

public class Product {
	
	List<Map<String, String>> products;
	String product_type = "product_sling_bags";
	BufferedReader reader;
	int size = 0;
	JFrame listening_ui;
	
	public void setListeningUi(JFrame ui)
	{
		listening_ui = ui;
	}
	
	public Product() {
		products = new ArrayList<>();
		load();
	}
	
	public String getCode()
	{
		String prefix = "UKNOWN";
		
		switch(product_type) {
			case "product_sling_bags":
				prefix = "SLB";
			break;
			case "product_backpacks":
				prefix = "BPB";
			break;
			case "product_belt_bags":
				prefix = "BLTB";
			break;
		}
		
		return prefix + (getSize() + 1);
	}
	
	
	public int getSize() 
	{
		return size;
	}
	
	public void load()
	{
		try {
			size = 0;
			products = new ArrayList<>();
			
			reader = new BufferedReader(new FileReader(product_type));
			String line = reader.readLine();
			
			while (line != null) {
				System.out.println(line);
		
				String data_arr[] = line.split(",");

				
				Map<String, String> product = new HashMap<String, String>();
			
				product.put("code", data_arr[0]);
				product.put("name", data_arr[1]);
				product.put("price", data_arr[2]);

				products.add(product);
				
				// read next line
				line = reader.readLine();
				
				size++;
			}
			
			reader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	public List<Map<String, String>> getItems()
	{
		return products;
	}
	
	public void update()
	{
		
	}
	
	public void add(String name, String price)
	{
		String data;
	
		
		try {
			File fout = new File(product_type);
			FileOutputStream fos = new FileOutputStream(fout);
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
			
			for (int i = 0; i < getSize(); i++) {
				bw.write(products.get(i).get("code") + "," + products.get(i).get("name") + "," + products.get(i).get("price"));
				bw.newLine();
			}
			
			data = getCode() + "," + name + "," + price;
			bw.write(data);
			
			bw.close();
			
	
			
		} catch (IOException e) {
	
			e.printStackTrace();
		}
		
		((Depstore) listening_ui).reloadTable();
	}
	
	public void delete(String code)
	{
		List<Map<String, String>> new_products = new ArrayList<>();
		int np_count = 0;
		
		for (int i=0; i < getSize(); i++) {
			if (code != products.get(i).get("code")) {
		  		
				new_products.add(products.get(i));
				np_count++;
			}
		}
		
		System.out.print(np_count);
		
		File fout = new File(product_type);
		FileOutputStream fos;
		try {
			fos = new FileOutputStream(fout);
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos));
			
			for (int i = 0; i < np_count; i++) {
				bw.write(new_products.get(i).get("code") + "," + new_products.get(i).get("name") + "," + new_products.get(i).get("price"));
				bw.newLine();
			}
			
			bw.close();
			
			products = new_products;
			
			((Depstore) listening_ui).reloadTable();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
