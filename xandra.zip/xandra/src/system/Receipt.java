package system;

import java.util.ArrayList;
import java.util.HashMap;

public class Receipt {
	
	String order_number;
	String customer_name;
	String customer_phone;
	String[] products;
	int total_price;
	
	public Receipt() {
		init();
	}
	
	public void init()
	{
		order_number = "";
		customer_name = "";
		customer_phone = "";
		products = new String[0];
		total_price = 0;
	}
	
	public void setOrderNumber(String order_num)
	{
		order_number = order_num;
	}
	
	public String getOrderNumber()
	{
		return order_number;
	}
	
	public void setCustomerName(String cus_name)
	{
		customer_name = cus_name;
	}
	
	public String getCustomerName()
	{
		return customer_name;
	}
	
	public void setCustomerPhone(String cus_phone)
	{
		customer_phone = cus_phone;
	}
	
	public String getCustomerPhone()
	{
		return customer_phone;
	}
	
	public void setProducts(String[] prods)
	{
		products = new String[prods.length];
		products = prods;
	}
	
	public String[] getProducts()
	{
		return products;
	}
	
	public void setTotalPrice(int total)
	{
		total_price = total;
	}
	
	public int getTotal()
	{
		return total_price;
	}

	
}
