package system;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;



public class Cart {
	
	List<Map<String, String>> products;
	String[] product_labels;
	int total = 0;
	int size = 0;
	Map<String, String> product_qty;
	Map<String, String> product_names;
	Map<String, String> product_prices;
	
	public Cart() {
		products = new ArrayList<>();
		product_qty = new HashMap<String, String>();
		product_names = new HashMap<String, String>();
		product_prices = new HashMap<String, String>();
		
	}
	
	public void addProduct(Map<String, String> product)
	{
		products.clear();
		products.add(product);
		size++;
	}
	
	public String[] getProductStrings()
	{
		return product_labels;
	}
	
	public int getTotal()
	{
		return total;
	}
	
	public int getSize()
	{
		return size;
	}
	
	public void reset()
	{
		products = new ArrayList<>();
		product_qty = new HashMap<String, String>();
		product_names = new HashMap<String, String>();
		product_prices = new HashMap<String, String>();
		total = 0;
		size = 0;
		product_labels = new String[0];
	}
	
	public void compute()
	{	
		Map<String, String> item = products.get(0);
		String code = item.get("code");
		int price = Integer.parseInt(item.get("price"));
		int qty = Integer.parseInt(item.get("qty"));
		
		total += (price * qty);
		
		if (product_qty.get(code) != null) {
		
			
			int tqty = (Integer.parseInt(product_qty.get(code)) + qty);
			
			product_qty.put(code, "" + tqty);
			product_names.put(code, item.get("name"));
			product_prices.put(code, item.get("price"));
		} else {
			product_qty.put(code, "" + qty);
			product_names.put(code, item.get("name"));
			product_prices.put(code, item.get("price"));
		}
	
		
		Set<String> code_set = product_qty.keySet();
		product_labels = new String[code_set.size()];
		
	
		
		for (int i = 0; i< code_set.size();i++) {
			String p_code = (String) code_set.toArray()[i];
		
			int total_qty = Integer.parseInt(product_qty.get(code_set.toArray()[i]));
			
			
			System.out.println(p_code + " - " + product_names.get(p_code) + " x " + total_qty + " ----- PHP " + (total_qty * Integer.parseInt(product_prices.get(p_code))));
			
			product_labels[i] =  p_code + " - " + product_names.get(p_code) + " x " + total_qty + " ----- PHP " + (total_qty * Integer.parseInt(product_prices.get(p_code)));
		}
		
		System.out.println("Total: " + total);
	}
}
