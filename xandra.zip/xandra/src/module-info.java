/**
 * 
 */
/**
 * @author Xandra
 *
 */
module DepartmentStore {
}