package xandra.ui;

import javax.swing.JFrame;

public class EditProduct extends JFrame 
{

}
