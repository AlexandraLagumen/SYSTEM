package xandra.ui;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.NumberFormat;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import system.models.Product;

public class CreateProduct extends JFrame
{
	JLabel lbl_name, lbl_price, info_message;
	JTextField name, price;
	JButton btn_create, btn_cancel;
	JFrame listening_ui;
	
	public void setListeningUi(JFrame ui)
	{
		listening_ui = ui;
	}

	
	public CreateProduct() 
	{
		setTitle("Add Product");
	
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBackground(Color.WHITE);
		setSize(350, 230);
	    setLocationRelativeTo(null);
	    setLayout(new BoxLayout(getContentPane(), BoxLayout.X_AXIS));
    	setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
	    
    	info_message = new JLabel("");
    	info_message.setForeground(Color.red);
	    lbl_name = new JLabel("Product Name:");
	    lbl_name.setAlignmentX(LEFT_ALIGNMENT);
	    lbl_price = new JLabel("Price (PHP):");
	    btn_create = new JButton("Submit");
	    btn_cancel = new JButton("Cancel");
	    
	    name = new JTextField();
	    price = new JTextField();
	    
	    price.addKeyListener(new KeyAdapter() {
	         public void keyPressed(KeyEvent ke) {
	             String value = price.getText();
	          
	             if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9') {
	            	 price.setEditable(true);
	                info_message.setText("");
	             } else {
	            	 price.setEditable(false);
	            	 
	            	 if (price.getText() != "") {
	            		 info_message.setText("* Enter only numeric digits(0-9)"); 
	            	 }
	            	
	            	
	            	 return;
	               
	             }
	          }
	         
	         @Override
	        public void keyReleased(KeyEvent e) {
	        	// TODO Auto-generated method stub
	        	 price.setEditable(true);
	        }
       });
	    
	    JPanel form = new JPanel();
	    form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
	    form.setMaximumSize(new Dimension(300, 400));;
	 
	    name.setMaximumSize(new Dimension(getMaximumSize().width,24));
	    form.add(Box.createRigidArea(new Dimension(10,10)));
	    price.setMaximumSize(new Dimension(getMaximumSize().width,24));
	    
	    form.add(Box.createRigidArea(new Dimension(10,10)));
	    form.add(lbl_name);
	    form.add(Box.createRigidArea(new Dimension(10,10)));
	    form.add(name);
	    form.add(Box.createRigidArea(new Dimension(10,10)));
	    form.add(lbl_price);
	    form.add(Box.createRigidArea(new Dimension(10,10)));
	    form.add(price);
	    form.add(Box.createRigidArea(new Dimension(10,10)));
	    form.add(info_message);
	    form.add(Box.createRigidArea(new Dimension(10,10)));
	    
	    btn_cancel.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				clearData();
				setVisible(false);
			}
	    });
	    
	    btn_create.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String val_name = name.getText(); 
				String val_price = price.getText();
				 info_message.setText(""); 
				
				if (val_name.toCharArray().length == 0) {
					 info_message.setText("Please add a product name."); 
					 return;
				}
				
				if (val_price.toCharArray().length == 0) {
					 info_message.setText("Please add a product price."); 
					 return;
				}
				
				Product products = new Product();
	
				products.setListeningUi(listening_ui);
				products.add(val_name, val_price);
			
				
				clearData();
				setVisible(false);
			}
	    });
	    
	    JPanel btn_section = new JPanel();
	    btn_section.setLayout(new BoxLayout(btn_section, BoxLayout.X_AXIS));
	    btn_section.add(btn_cancel);
	    btn_section.add(Box.createRigidArea(new Dimension(20,20)));
	    btn_section.add(btn_create);

	    form.add(btn_section);
	    
	    add(Box.createRigidArea(new Dimension(20,20)));
	    add(form);
	}
	
	private void clearData()
	{
		name.setText("");
		price.setText("");
	}
}
