package xandra;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Login extends JFrame{
   
   JFrame inputFrame = new JFrame();
   JFrame outputFrame = new JFrame();
   JFrame main;
       
   JPanel pnlMain = new JPanel();
   JPanel pnlSub = new JPanel();
   
   JLabel lblFirstName = new JLabel ("First Name: ");
   JLabel lblLastName = new JLabel ("Last Name: ");
   JLabel lblMiddleName = new JLabel ("Middle Name: ");
   JLabel lblMobileNumber = new JLabel ("Mobile Number: ");
   JLabel lblEmailAddress = new JLabel ("Email Address: ");
   
   JButton btnSubmit = new JButton ("Submit");
   JButton btnClearAll = new JButton ("ClearAll");
   JButton btnOkay = new JButton ("Okay");
   
   JTextField fldFirstName = new JTextField(16);
   JTextField fldLastName = new JTextField(16);
   JTextField fldMiddleName = new JTextField(16);
   JTextField fldMobileNumber = new JTextField(16);
   JTextField fldEmailAddress = new JTextField(16);
   


   JTextArea outputArea = new JTextArea (10, 25);
   
   FlowLayout fl = new FlowLayout();
   Font setFont = new Font ("",Font.BOLD, 18);
   
   public static void main (String[] args) {
	   Depstore test = new Depstore();
	   test.show();
   }
   
   public Login() {
     this.setSize(350,350);
     this.setLocation(200,200);
     this.setTitle("Log in");
     this.setResizable(true);
     this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     main = this;
     
     outputArea.setBackground(Color.LIGHT_GRAY);
     outputArea.setEditable(false);
     outputArea.setFont(setFont);

     fldFirstName.setFont(setFont);
     fldLastName.setFont(setFont);
     fldMiddleName.setFont(setFont);
     fldMobileNumber.setFont(setFont);
     fldEmailAddress.setFont(setFont);
     

     pnlMain.add(lblFirstName);
     pnlMain.add(fldFirstName);
     pnlMain.add(lblLastName);
     pnlMain.add(fldLastName);
     pnlMain.add(lblMiddleName);
     pnlMain.add(fldMiddleName);
     pnlMain.add(lblMobileNumber);
     pnlMain.add(fldMobileNumber);
     pnlMain.add(lblEmailAddress);
     pnlMain.add(fldEmailAddress);
      

     btnSubmit.addActionListener(new actionButton1());
     pnlMain.add(btnSubmit);
     btnClearAll.addActionListener(new actionButton2());
     pnlMain.add(btnClearAll);

     this.add(pnlMain);
     this.setVisible(true);
     
     
     setLocationRelativeTo(null);
}

     class actionButton1 implements ActionListener {
		     @Override
		     public void actionPerformed(ActionEvent a) {
			
			     Depstore test = new Depstore();
			  
		     
		     test.show();
		   }
	   }
     
     
   
    class actionButton2 implements ActionListener {
    	
    	@Override
	    public void actionPerformed(ActionEvent e){
		    fldFirstName.setText("");
		    fldMiddleName.setText("");
		    fldLastName.setText("");
		    fldEmailAddress.setText(""); 
		    fldMobileNumber.setText("");
		    outputArea.setText("");
	   }
   }
   
   class actionButton3 implements ActionListener {
@Override

   public void actionPerformed(ActionEvent e){
   fldFirstName.setText("");
   fldMiddleName.setText("");
   fldLastName.setText("");
   fldEmailAddress.setText(""); 
   fldMobileNumber.setText("");
   outputArea.setText("");
outputFrame.dispose();
btnSubmit.setEnabled(true);
   }
}
   
}
