package xandra;



import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.print.PrinterException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import system.Cart;
import system.Receipt;
import system.models.Product;
import xandra.ui.CreateProduct;

public class Depstore extends JFrame
{
    JLabel Customer,Name,Contact,Hawk;
    JTextField tNumber,tName,tContact,tHawk;
    JComboBox c1,c2;
    JFrame listening_ui;
    JTable product_table;
    
    JButton reset,print,receipt, btn_create_product, btn_edit_product, btn_add_product, btn_delete_product;
    Product products;
    String selected_product;
    Cart cart;
    Receipt receipt_class;
    JFrame qty;
    JPanel receipt_ui;
    
    public Depstore()
    {
        final CreateProduct ui_create_product = new CreateProduct();
        listening_ui = this;
        ui_create_product.setListeningUi(listening_ui);
        products = new Product();
        cart = new Cart();
        receipt_class = new Receipt();
    

        //labels
        
        Customer = new JLabel ("Customer no:");
        Customer.setBounds(20, 50, 120, 30);
        
        Name = new JLabel ("Name:");
        Name.setBounds(20, 100, 120, 30);
        
        Contact = new JLabel ("Contact:");
        Contact.setBounds(20, 150, 120, 30);
        
        Hawk = new JLabel ("Hawk:");
        Hawk.setBounds(20, 200, 120, 30);
        
            
        //set ng text fields
        tNumber = new JTextField();
        tNumber.setBounds(150, 50, 200, 30);
        
        tName = new JTextField();
        tName.setBounds(150, 100, 200, 30);
        
        tContact = new JTextField();
        tContact.setBounds(150, 150, 200, 30);
        
        loadTable();
        

        
        //combo box
        String bag []={"Sling bag","Backpack","Belt bag"};
        c1 = new JComboBox(bag);
        c1.setBounds(200, 200, 120, 30);
        
        btn_create_product = new JButton("Create");
        btn_create_product.setBounds(15, 250, 70, 30);
        getContentPane().add(btn_create_product);
        
        btn_edit_product = new JButton("Edit");
        btn_edit_product.setBounds(80, 250, 70, 30);
        getContentPane().add(btn_edit_product);
        
        btn_delete_product = new JButton("Delete");
        btn_delete_product.setBounds(145, 250, 70, 30);
        getContentPane().add(btn_delete_product);
        
        btn_add_product = new JButton("Add to Cart");
        btn_add_product.setBounds(210, 250, 100, 30);
        getContentPane().add(btn_add_product);
        
        btn_create_product.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
            
               ui_create_product.show();
        
            }        
        });
        
        btn_delete_product.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
            	String code = getSelectedProductCode();
            	 int input = JOptionPane.showConfirmDialog(null, "Are you sure?");
            	 
            	 if (input == 0) {
            		 products.setListeningUi(listening_ui);
            		 products.delete(code);
            	 }
    
            }        
        });
        
        btn_add_product.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
            	loadProductQTY().setVisible(true);
            }        
        });
        
        
        
        
    	
        //buttons
        reset = new JButton("reset");
        reset.setBounds(400, 100, 80, 40);
        
        print = new JButton("print");
        print.setBounds(490, 100, 80, 40);
        
        receipt = new JButton("receipt");
        receipt.setBounds(580, 100, 80, 40);
        
       
        // add content pane
        getContentPane().add(reset);
        getContentPane().add(receipt);
        getContentPane().add(print);
      
        getContentPane().add(Customer);
        getContentPane().add(Name);
        getContentPane().add(Contact);
        getContentPane().add(Hawk);
        getContentPane().add(tName);
        getContentPane().add(tContact);
        getContentPane().add(tNumber);
        
       
        loadReceipt();
        
        getContentPane().add(c1);
        
        
        setSize(700,550);
        setLayout(null);
        
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLocationRelativeTo(null);
        
        //buttons actions
        
        reset.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
               receipt_class.init();
               cart.reset();
               
               reloadReceipt();
               
            }        
        });
        
        print.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
            	
            }
        });
        
        
    }
    
    private void reloadReceipt() 
    {
    	listening_ui.remove(receipt_ui);
    	listening_ui.revalidate();
    	listening_ui.repaint();
    	loadReceipt();
       	listening_ui.revalidate();
    	listening_ui.repaint();
    }
    
    private void loadReceipt()
    {
    	 //TextArea
        receipt_ui = new JPanel();
        receipt_ui.setBounds(400, 160, 200, 200);
        receipt_ui.setSize(260,260);
        receipt_ui.setLayout(null);
        receipt_ui.setBackground(Color.white);
        
        JLabel order_number = new JLabel("Order Number: ");
        order_number.setBounds(20, 0, 120, 40);
        receipt_ui.add(order_number);
        
        JLabel order_number_val = new JLabel(receipt_class.getOrderNumber());
        order_number_val.setBounds(20, 15, 120, 40);
        order_number_val.setForeground(Color.gray);
        receipt_ui.add(order_number_val);
        
        JLabel orders_lbl = new JLabel("Orders: ");
        orders_lbl.setBounds(20, 38, 60, 30);
        receipt_ui.add(orders_lbl);
        
        JPanel order_log = new JPanel();
        order_log.setBackground(Color.WHITE);
        order_log.setSize(350, 340);
        order_log.setLayout(null);
        
        String[] logs = receipt_class.getProducts();
        int log_gap = 20;
        
        for (int i = 0; i< logs.length; i++) {
        	JLabel log = new JLabel(logs[i]);
        	log.setBounds(20, 43 + (log_gap * (i+1)), 250, 30);
        	order_log.add(log);
        }
        
        JLabel total_lbl = new JLabel("Total: ");
        total_lbl.setBounds(20, 220, 60, 30);
        receipt_ui.add(total_lbl);
        
        JLabel total_val = new JLabel("PHP " + receipt_class.getTotal() + ".00");
        total_val.setBounds(70, 220, 200, 30);
        receipt_ui.add(total_val);
        
        receipt_ui.add(order_log);
        
        getContentPane().add(receipt_ui);
    }
    
    private JFrame loadProductQTY() 
    {
    	qty = new JFrame();
    	
    	setTitle("Add Product");
    	
    	qty.setDefaultCloseOperation(EXIT_ON_CLOSE);
    	qty.setBackground(Color.WHITE);
    	qty.setSize(150, 170);
    	qty.setLocationRelativeTo(null);
    	qty.setLayout(null);
    	
    	JLabel lbl = new JLabel("How many?");
    	lbl.setBounds(20, 10, 100, 50);
    	qty.add(lbl);
    	
    	final JTextField quantity = new JTextField();
    	quantity.setBounds(20, 50, 100, 30);
    	quantity.setText("1");
    	qty.add(quantity);
    	
    	
    	quantity.addKeyListener(new KeyAdapter() {
	         public void keyPressed(KeyEvent ke) {
	             String value = quantity.getText();
	          
	             if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9') {
	            	 quantity.setEditable(true);
	               
	             } else {
	            	 quantity.setEditable(false);
	            	 return;
	               
	             }
	          }
	         
	         @Override
	        public void keyReleased(KeyEvent e) {
	        	// TODO Auto-generated method stub
	        	 quantity.setEditable(true);
	        }
      });
    	
    	JButton qty_add = new JButton("Add");
    	qty_add.setBounds(20, 90, 100, 30);
    	
    	qty_add.addActionListener(new ActionListener()
	      {
	          public void actionPerformed(ActionEvent e)
	          {
	        	  Map<String, String> product = getSelectedProduct();
	        	  product.put("qty", quantity.getText());
	        
	        	  cart.addProduct(product);
	        	  cart.compute();
	        	  
	        	  receipt_class.setTotalPrice(cart.getTotal());
	        	  receipt_class.setProducts(cart.getProductStrings());
	        	  receipt_class.setCustomerName(tName.getText());
	        	  receipt_class.setCustomerPhone(tContact.getText());
	        	  receipt_class.setOrderNumber(tNumber.getText());
	        	  
	        	  qty.setVisible(false);
	        	  
	        	  reloadReceipt();
	          }        
	      });
    	
    
    	qty.add(qty_add);
    	
    	
    	
    	return qty;
    }
    
    public String getSelectedProductCode()
    {
    	return product_table.getModel().getValueAt(product_table.getSelectedRow(), 0).toString();
    }
    
    public Map<String, String> getSelectedProduct()
    {
    	String code = getSelectedProductCode();
        List<Map<String, String>> items = products.getItems();
        Map<String, String> selected = null;
        
        for (int i=0; i < products.getSize(); i++) {
        	if (code == items.get(i).get("code")) {
        		selected = items.get(i);
        	}
        }
        
    	return selected;
    }
    
    public void reloadTable()
    {
    	listening_ui.remove(product_table);
    	listening_ui.revalidate();
    	listening_ui.repaint();
    	loadTable();
       	listening_ui.revalidate();
    	listening_ui.repaint();
    }
    
    private void loadTable()
    {
    	products.load();
    	
    	int product_count = products.getSize();
        List<Map<String, String>> items = products.getItems();
        

        String[] column_names = {"Product Code", "Product Name", "Price"};
        Object[][] data = new Object[product_count][3];
        
        for (int i = 0; i < product_count; i++) {
          	data[i][0] = items.get(i).get("code");;
        	data[i][1] = items.get(i).get("name");
        	data[i][2] = items.get(i).get("price");
        }
        
        product_table = new JTable(data, column_names);
        product_table.setDefaultEditor(Object.class, null);
        product_table.setBounds(15, 300, 300, 200);
        
        getContentPane().add(product_table);
    }
    
    public static void main(String[] args){
        new Depstore();
      }
}